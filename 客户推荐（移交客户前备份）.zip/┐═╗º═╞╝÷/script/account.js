define(function(require, exports, module){
	function _account(){};
	_account.prototype={
		/*绑定银行卡*/
		bindingBankCard:function(){
			
		},
		/*绑定支付宝*/
		bindingPaypal:function(){
			
		}
		
	}
	_account.prototype.constructor=_account;
	module.exports=new _account();
});