define(function(require, exports, module){
	function _base(){};
	_base.prototype={
		/*select选择选项后，给显示层DIV赋值
		*tag  点击的select对象
		*domId 显示层的元素
		*/
		setBaseSelectedValue:function(tag,domId){
			/*获取seleed*/
			var selected=$(tag).find('option').not(function(){return !this.selected});
			var selectedValue=selected.text();
			var selectedId=selected.attr('o_id');
			/*显示值*/
			if(selectedId=="其他"){
				if(api.systemType=="ios"){
					$(domId).css('color','#999');
				}
				if(domId=="#area"){
					$(domId).removeAttr('disabled');
					$('#area').focus();
					$(domId).attr('placeholder','请输入面积');
				}else if(domId=="#price"){
					$(domId).attr('placeholder','请输入价格');
				}
				$(domId).removeAttr('disabled');
				$(domId).focus();
				$(domId).val(null);
			}else if(domId=="#area"||domId=="#price"){
				if(api.systemType=="ios"){
					$(domId).css('color','#000');
				}
				$(domId).removeAttr('disabled');
				$(domId).val(selectedValue);
				$(domId).attr('disabled','disabled');
			}else{
				$(domId).text(selectedValue);
			}
			/*赋selected的id到显示层的属性上*/
			try{
				$(domId).attr('estateId',selectedId);
			}catch(err){}
			/*给必选项赋属性值-用于检查*/
			try{
				$(domId).attr("check",selectedValue);
			}
			catch(err){}
		},
		/*recommendInfo_frame-数据交互*/
		requestBaseRecommendData:function(key,reload){
				$('.noDataBox').hide();
				postData.page=page;
			    /*搜索参数存在*/
			    if(key!=""&&key!='filtrate'){
			        postData.key=key;
			    }
			    if(key=="filtrate"){
			    	postData.page=0;
			    }
			    g.goAjax('Process/customer_recommend_list',postData,function(ret){
			    	page+=1;
			        var node='';
			        for(var i=0; i<ret.info.length;i++){
			            if(ret.info[i].create_time==undefined){
			                continue;
			            }
			            node+='<div class="ub ub-ver borb-gra-1 bg-wh marl-15" c_id="'+ret.info[i].c_id+'" c_item="'+ret.info[i].c_item+'"><div class="ub mart-15 marr-15"><div class="ub"><div class="tx-14 tx-bla marr-10">'+ret.info[i].c_name+'</div><div class="tx-14 tx-bla-2">（'+ret.info[i].c_tel+'）</div></div><div class="ub-f1"></div><div class="tx-14 tx-bla marl-10">推荐时间：<span class="tx-14 tx-orange">'+ret.info[i].create_time+'</span></div></div><div class="tx-14 tx-bla mart-15 marb-15">当前进度：</div><div class="ub marr-15 marb-15">';
			            if(ret.info[i].c_item_status=="0"){
			            	node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active btn-gray" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			            }else if(ret.info[i].c_item_status=="2"){
			                    node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			            }else if(ret.info[i].c_item_status=="3"){
			                    node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			            }else if(ret.info[i].c_item_status=="4"){
			                    node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			            }else if(ret.info[i].c_item_status=="5"){
			                    node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			            }
			        }
			        if(reload=='reload'){
		                $(".list").children().remove();
		                $('.list').append(node);
		                api.refreshHeaderLoadDone();
			        }else{
			            $('.list').append(node);
			        }
			        api.hideProgress();
			        node='';
			    },function(ret){
			        api.refreshHeaderLoadDone();
			        if(reload=='reload'){
			        	$(".list").children().remove();
			        }
			        /*如果数据为空或搜索的结果为空，则显示提醒图*/
			        if(page==0){
			            $('.noDataBox').show();
			        }else if(key!=""){
			            $('.noDataBox').show();
			        }
			        api.hideProgress();
			    })
		},
		/*接待详情列表-receiveInfo_frame*/
		requestBaseReceiveInfoData:function(key,reload){
			$('.noDataBox').hide();
			postData.page=page;
			/*搜索参数存在*/
			if(key!=""&&key!='filtrate'){
			    postData.key=key;
			}
			if(key=="filtrate"){
			    postData.page=0;
			}
			g.goAjax('Process/recept_detail_list',postData,function(ret){
			    page+=1;
			    var node='';
			    var parentNode=$('.list');
			    for(var i=0; i<ret.info.length;i++){
			        if(ret.info[i].create_time==undefined){
			            continue;
			        }
			        node+='<div class="ub ub-ver borb-gra-1 bg-wh marl-15" c_id="'+ret.info[i].c_id+'" c_item="'+ret.info[i].c_item+'" c_name="'+ret.info[i].c_name+'" c_phone="'+ret.info[i].c_tel+'"><div class="ub mart-15 marr-15 listDetails" c_id="'+ret.info[i].c_id+'"><div class="ub"><div class="tx-14 tx-bla marr-10">'+ret.info[i].c_name+'</div><div class="tx-14 tx-bla-2">（'+ret.info[i].c_tel+'）</div></div><div class="ub-f1"></div><div class="tx-14 tx-bla marr-5">推荐时间：<span class="tx-14 tx-orange">'+ret.info[i].create_time+'</span></div></div><div class="tx-14 tx-bla mart-15 marb-15 listDetails" c_id="'+ret.info[i].c_id+'">当前进度：</div><div class="ub marr-15 marb-15" p_id="'+ret.info[i].p_id+'">';
			        if(ret.info[i].c_item_status=="1"){
			                node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'" p_id="'+ret.info[i].p_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			        }else if(ret.info[i].c_item_status=="2"){
			                node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'" p_id="'+ret.info[i].p_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			        }else if(ret.info[i].c_item_status=="3"){
			                node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'" p_id="'+ret.info[i].p_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>4.</span>成交</div></div></div>';
			        }else if(ret.info[i].c_item_status=="4"){
			                node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active" Cid="'+ret.info[i].c_id+'" p_id="'+ret.info[i].p_id+'"><span>4.</span>成交</div></div></div>';
			        }else if(ret.info[i].c_item_status=="5"){
			            node+='<div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>1.</span>验重</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>2.</span>邀约</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc" Cid="'+ret.info[i].c_id+'"><span>3.</span>接待</div><div class="plan-interval-blur"></div><div class="ub-f1 plan-btn-2 ub ub-ac ub-pc btn-active dealSucceed" Cid="'+ret.info[i].c_id+'" p_id="'+ret.info[i].p_id+'"><span>4.</span>成交</div></div></div>';
			        }
			    }
			    if(reload=='reload'){
		            $(".list").children().remove();
		            $('.list').append(node);
		            api.refreshHeaderLoadDone();
			    }else{
			        $('.list').append(node);
			    }
			    api.hideProgress();
			    node="";
			},function(ret){
			    api.refreshHeaderLoadDone();
			    if(reload=='reload'){
			    	$(".list").children().remove();
			    }
			    /*如果数据为空或搜索的结果为空，则显示提醒图*/
			    if(page==0){
			        $('.noDataBox').show();
			    }else if(key!=""){
			        $('.noDataBox').show();
			    }
			    api.hideProgress();
			})
		}
	}
	_base.prototype.constructor=_base;
	module.exports=new _base();
});