define(function(require, exports, module){
	function _public(){
		this.phoneReg= /^1\d{10}$/;//电话号码验证
		this.passwordReg=/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$/; //密码规则验证
		this.noZeroBeginNum = /^[1-9][0-9]*$/;//非零开头的数字组合
		this.numAlp = /^[0-9a-zA-Z]*$/g;//数字和字母
		this.verificationCode=/^[0-9]{4,6}$/ //验证码验证
		this.money=/^(d*.d{0,2}|d+).*$/;

	}
	_public.prototype={
		/*忘记密码->修改密码-成功后执行
		* 给输入框赋值
		* dom 赋值的目标元素
		* value 值
		*/
		setBaseMobileValue:function(dom,value){
			$(dom).val(value);
		},
		/*输入框验证是否为空
		*inputList:需要验证的输入框列表，例子：[{inputDom:Dom,tips:'请输入密码！'}]
		*/
		checkNull:function(inputList){
			for(var i=0;i<inputList.length;i++){
				if($api.trim($api.val($api.dom(inputList[i].inputDom)))==""){
					api.toast({
						msg:inputList[i].tips,
						duration:1500,
						location:'bottom',
					});
					return false;
				}
			}
			return true;
		},
		/*获取验证码
		*phoneNumber 电话号码
		*tag 按钮对象
		*/
		getPublicCode:function(tag){
			/*如果电话号码不符合正则，则返回*/
			if (!this.phoneReg.test($api.val($api.byId("phone")))){
			    g.toastMsg('请正确输入手机号码！');
			    return;
			}
			/*ajax数据交互-开始*/
			var postDate={mobile:$api.val($api.byId("phone"))};
			var countDown=60;
			$api.text(tag,countDown);
			/*ajax数据交互-开始*/
			g.goAjax('Public/send_verifycode',postDate,function(ret){
			    /*阻止限制时间之内二次点击*/
			    $api.css($api.dom('.shield'),'z-index:9');
			    $api.addCls(tag,'bg-short-active');
			    for(var i=0;i<countDown;i++){
			        setTimeout(function(){
			            countDown-=1;
			            if(countDown==0){
			                $api.removeCls(tag, 'bg-short-active');
			                $api.text(tag,'获取验证码');
			                /*开启点击功能*/
			                $api.css($api.dom('.shield'),'z-index:-1');
			            }else{
			                $api.text(tag,countDown);
			            }
			        },i*1000);
			    }
			    g.toastMsg(ret.info);
			    return true;
			})
			/*ajax数据交互-结束*/
		},
		/*注册*/
		registerPublic:function(cid){
			var inputList=[
			    {
			        inputDom:"#phone",
			        tips:"电话号码不能为空！"
			    },
			    {
			        inputDom:"#verifyCode",
			        tips:"验证码不能为空！"
			    },
			    {
			        inputDom:"#nickName",
			        tips:"昵称不能为空"
			    },
			    {
			        inputDom:"#password",
			        tips:"密码不能为空！"
			    },
			]
			var check=this.checkNull(inputList);
			if(!check){
			    return;
			};
			if (!this.passwordReg.test($api.val($api.byId("password")))){
			    g.toastMsg('请输入6~20位数字+字母组合的密码！');
			    return;
			};
			if($api.val($api.byId("password"))!=$api.val($api.byId("re_pwd"))){
			    g.toastMsg('两次密码不一致！');
			    return;
			};
			g.showProgress('正在注册...');
			/*ajax数据交互-开始*/
			var postDate={
			    cid:cid,
			    mobile:$('#phone').val(),
			    verify_code:$('#verifyCode').val(),
			    nickname:$('#nickName').val(),
			    password:$('#password').val(),
			    confirm:$('#re_pwd').val(),
			    recommend_code:$('#re_code').val(),
			    systemType:api.systemType,
			    deviceToken:api.deviceToken
			};
			g.goAjax('Public/register',postDate,function(ret){
			    $api.setStorage("mobile",$('#phone').val());
			    $api.setStorage("password",$('#password').val());
			    $api.setStorage("mid",ret.mid);
			    api.hideProgress();
			    g.toastMsg(ret.info);
			    setTimeout(function(){
			        g.openModuleWin('Base','base');
			        setTimeout(function(){
			        	api.closeWin();
			        },200)
			    },1000);
			},function(ret){
				api.hideProgress();
				g.toastMsg(ret.err);
			})
			/*ajax数据交互-结束*/
		},
		/*修改登录密码*/
		resetPublicLoginPwd:function(){
			var inputList=[
			    {
			        inputDom:"#phone",
			        tips:"电话号码不能为空！"
			    },
			    {
			        inputDom:"#verifyCode",
			        tips:"验证码不能为空！"
			    },
			    {
			        inputDom:"#password",
			        tips:"密码不能为空！"
			    },
			]
			var check=this.checkNull(inputList);
			if(!check){
			    return;
			};
			if (!this.passwordReg.test($api.val($api.byId("password")))){
			    g.toastMsg('请输入6~20位数字+字母组合的密码！');
			    return;
			};
			if($api.val($api.byId("password"))!=$api.val($api.byId("re_pwd"))){
			    g.toastMsg('两次密码不一致！');
			    return;
			};
			g.showProgress('正在修改...');
			/*ajax数据交互-开始*/
			var postDate={
			    mobile:$('#phone').val(),
			    verify_code:$('#verifyCode').val(),
			    password:$('#password').val(),
			    confirm:$('#re_pwd').val()
			};
			g.goAjax('Public/pass_reset',postDate,function(ret){
				$api.clearStorage();
			    $api.setStorage("mobile",$('#phone').val());
			    /*修改登录页面的mobile输入框的值-结束*/
			    api.hideProgress();
			    g.toastMsg(ret.info);
			    setTimeout(function(){
			        g.openModuleWin('Public','login');
			    },1500);
			},function(ret){
				api.hideProgress();
				g.toastMsg(ret.err);
			})
			/*ajax数据交互-结束*/
		},
		/*登录*/
		loginPublic:function(cid){
			$('input').blur();
			/*如果电话号码不符合正则，则返回*/
			if (!this.phoneReg.test($api.val($api.byId('phoneNumber')))){
			    g.toastMsg('请输入正确的手机号码！');
			    return;
			};
			if (!this.passwordReg.test($api.val($api.byId('passWord')))){
			    g.toastMsg('请输入6~20位正确的密码！');
			    return;
			};
			g.showProgress('正在登陆...');
			/*ajax数据交互-开始*/
			var postData={
			    cid:cid,
			    mobile:$('#phoneNumber').val(),
			    password:$('#passWord').val(),
			    systemType:api.systemType,
			    deviceToken:api.deviceToken
			};
			g.goAjax('Public/login',postData,function(ret){
			    api.hideProgress();
			    $api.setStorage('mobile',$('#phoneNumber').val());
			    $api.setStorage('password',$('#passWord').val());
			    $api.setStorage("mid",ret.mid);
			    g.openModuleWin('Base','base')
			},function(ret){
			    api.hideProgress();
			    g.toastMsg(ret.err);
			});
			/*ajax数据交互-结束*/
		}
	}
	_public.prototype.constructor=_public;
	module.exports=new _public();
});