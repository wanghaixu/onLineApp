define(function(require, exports, module){
	function _member(){};
	_member.prototype={
		/*点击注销事件*/
		logoutMember:function(){
			api.confirm({
				title : "注销提醒：",
				msg : "确定退出吗？",
				buttons : ["再逛一下", "确定"]
			}, function(ret, err) {
				if (ret.buttonIndex == 1) {
				} else {
					g.showProgress('正在注销...');
					/*数据交互-开始*/
					var postData = {
						mobile : $api.getStorage('mobile'),
						password : $api.getStorage('password'),
						mid : $api.getStorage('mid'),
					}
					g.goAjax('Public/logout', postData, function(ret) {
						/*清除缓存*/
						$api.clearStorage ();
						$api.rmStorage('ca_account');
						$api.rmStorage('ca_account');
						api.closeWin({
							name : 'base'
						});
						api.hideProgress();
						/*跳转到登陆页，关闭所有打开的页面*/
						g.openModuleWin('Public', 'login');
						api.closeWin({
							name : 'memberData'
						});
					},function(ret){
						api.hideProgress();
						g.toastMsg(ret.err);
					})
					/*数据交互-结束*/
				}
			});
		},
		/*长按复制邀请码*/
		copyMemberInvitation:function(){
			var timeOutEvent = 0;
			$('#remCode').on('touchstart', function() {
				timeOutEvent = setTimeout(function() {
					var obj = api.require('clipBoard');
					obj.set({
						value : $('#remCode').text()
					}, function(ret, err) {
						if (ret.status) {
							g.toastMsg('已复制到剪切板');
						} else {
							g.toastMsg('复制失败，请稍后重试');
						}
					});
				}, 500)
				return false;
			});
			$('#remCode').on('touchend', function() {
				clearTimeout(timeOutEvent);
			});
			$('#remCode').on('touchmove', function() {
				clearTimeout(timeOutEvent);
			});
		},
		openFrameMember:function(moduls,frame){
			api.openFrame({
	            name: frame,
	            url: '../html/'+moduls+'/'+frame+'.html',
	            rect: {
		            x:0,
		            y:0,
		            w:'auto',
		            h:'auto'
	            }
	        });
		},
		/*银行卡的修改*/
		resetBank:function(){
			g.showProgress('正在修改...');
		    var postData={
		        mobile:$api.getStorage('mobile'),
		        password:$api.getStorage('password'),
		        mid:$api.getStorage('mid'),
		        b_name:$('#userName').val(),
		        b_bank:$('#bankName').val(),
		        b_account:$('#bankCd').val()
		    };
            g.goAjax('Member/bank_change',postData,function(ret){
            	api.hideProgress();
    	        g.toastMsg(ret.info);
    	        $api.setStorage('bankName',postData.b_bank);
    	        $api.setStorage('bankCd',postData.b_account);
    	        $api.setStorage('userName',postData.b_name);
    	        setTimeout(function(){g.goback()},1000)
        	},function(ret){
        		g.toastMsg(ret.err);
        		api.hideProgress();
        	});
		},
		/*支付宝的修改*/
		resetPaypal:function(){
			g.showProgress('正在修改...');
	        var postDataEdit={
	            mobile:$api.getStorage('mobile'),
	            password:$api.getStorage('password'),
	            mid:$api.getStorage('mid'),
	            zhf_account:$('#phone').val(),
	            zhf_name:$('#userName').val()
	        };
	        g.goAjax('Member/zhifubao_change',postDataEdit,function(ret){
	        	api.hideProgress();
	            g.toastMsg(ret.info);
	            $api.setStorage('zhfName',postDataEdit.zhf_name);
	            $api.setStorage('zhfAccount',postDataEdit.zhf_account);
	            setTimeout(function(){g.goback()},1000)
	        },function(ret){
	        	api.hideProgress();
	        	g.toastMsg(ret.err);
	        });
		},
		/*用户昵称的修改*/
		resetNick:function(){
			if($.trim($('input').val())!=""){
				g.showProgress('正在修改...');
			    /*ajax-请求数据-开始*/
			    var postDate={
			        mobile:$api.getStorage('mobile'),
			        password:$api.getStorage('password'),
			        mid:$api.getStorage('mid'),
			        nickname:$('input').val()
			    }
			    g.goAjax('Member/nickname',postDate,function(ret){
			    	api.hideProgress();
			        g.toastMsg(ret.info);
			        /*改变原先页面的值-开始*/
			        var data={
			            name:$('input').val()
			        };
			        //修改本地数据表的名字
			        var memberData_ret=$api.getStorage('memberData');
			        memberData_ret.info.m_nickname=data.name;
			        $api.setStorage('memberData',memberData_ret)
			        //修改资料页面的名字
			        g.execScript('memberData','memberData_frame',function(data){
			            $('#name').text(data.name);
			        },data)
			        //修改主页面的名字
			        g.execScript('base','baseGroup',function(data){
			            $('#userName').text(data.name);
			        },data)
			        /*改变原先页面的值-结束*/
			        setTimeout(function(){
			            g.goback();
			        },1500)
			    },function(ret){
			    	api.hideProgress();
			    	g.toastMsg(ret.err);
			    })
			    /*ajax-请求数据-结束*/
			}
			else{
			    g.toastMsg("昵称不能为空");
			}
		}
	}
	_member.prototype.constructor=_member;
	module.exports=new _member();
});